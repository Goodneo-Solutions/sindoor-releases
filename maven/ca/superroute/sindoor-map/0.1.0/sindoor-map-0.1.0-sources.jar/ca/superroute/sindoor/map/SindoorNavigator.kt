package ca.superroute.sindoor.map

import ca.superroute.sindoor.SindoorEstimate
import ca.superroute.sindoor.SindoorException
import ca.superroute.sindoor.SindoorLngLat
import ca.superroute.sindoor.SindoorPoint
import ca.superroute.sindoor.SindoorRoute
import ca.superroute.sindoor.SindoorSite
import ca.superroute.smap.SMap
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Deferred
import kotlin.math.roundToLong

/** The navigator's colours (CSS `#rrggbb`). */
data class SindoorNavigatorColors(
    val dot: String = "#1a73e8",
    val accuracy: String = "#1a73e8",
    val accuracyOpacity: Float = 0.15f,
    val route: String = "#1a73e8",
)

/**
 * How the navigator behaves.
 *
 * @param id the indoor layer's id on the map
 * @param control the level switcher
 * @param level the level shown first (default sMap's: the level of ordinal 0, else the lowest)
 * @param role `customer`, `staff`, `delivery` or `all`
 * @param profile movement profile (default the site's pedestrian)
 * @param follow keep the shown level on the walker's
 * @param text any [SindoorNavigator.DEFAULT_TEXT] key, for translations
 * @param stepsView where the step list goes (none: no list)
 * @param onSteps told every new step list (also an empty one), e.g. for the app's own list
 */
data class SindoorNavigatorOptions(
    val id: String = "sindoor",
    val control: Boolean = true,
    val level: String? = null,
    val role: String = "customer",
    val profile: String? = null,
    val follow: Boolean = true,
    val text: Map<String, String> = emptyMap(),
    val colors: SindoorNavigatorColors = SindoorNavigatorColors(),
    val stepsView: SindoorStepsView? = null,
    val onSteps: ((List<SindoorStepLine>) -> Unit)? = null,
)

/** One line of the step list: the step's [kind], [level], [distanceMm] and its [text]. */
data class SindoorStepLine(val kind: String, val level: String?, val distanceMm: Double, val text: String)

/** One level's part of a route as the map draws it: layer [id], [level] and longitude / latitude coordinates. */
data class SindoorRouteLine(val id: String, val level: String, val coordinates: List<SindoorLngLat>)

/**
 * The ready navigation screen (sIndoor docs/DESIGN.md Part 2h, IK5): a site drawn as sMap's indoor layer, a level
 * switcher, the blue dot, the route line and the step list, on an sMap map. Call it on the main thread.
 */
class SindoorNavigator(
    val surface: SindoorMapSurface,
    val site: SindoorSite,
    val options: SindoorNavigatorOptions = SindoorNavigatorOptions(),
) {
    /** A navigator on sMap Android's map view. */
    constructor(map: SMap, site: SindoorSite, options: SindoorNavigatorOptions = SindoorNavigatorOptions()) : this(SMapSurface(map), site, options)

    companion object {
        val DEFAULT_TEXT: Map<String, String> = linkedMapOf(
            "start" to "Start",
            "arrive" to "Arrive",
            "straight" to "Go straight",
            "slight_left" to "Bear left",
            "slight_right" to "Bear right",
            "left" to "Turn left",
            "right" to "Turn right",
            "sharp_left" to "Turn sharp left",
            "sharp_right" to "Turn sharp right",
            "u_turn" to "Turn around",
            "connector" to "Change level",
            "level" to "Level",
            "metres" to "{n} m",
            "no_route" to "No walking route to this place.",
        )

        private val VAR = Regex("""\{(\w+)\}""")

        internal fun fmt(t: String, vars: Map<String, String>): String = VAR.replace(t) { vars[it.groupValues[1]] ?: "" }

        /** A navigator once the map has drawn the site. */
        suspend fun create(map: SMap, site: SindoorSite, options: SindoorNavigatorOptions = SindoorNavigatorOptions()): SindoorNavigator =
            SindoorNavigator(map, site, options).ready.await()

        /** [create] on any [SindoorMapSurface]. */
        suspend fun create(surface: SindoorMapSurface, site: SindoorSite, options: SindoorNavigatorOptions = SindoorNavigatorOptions()): SindoorNavigator =
            SindoorNavigator(surface, site, options).ready.await()
    }

    val text: Map<String, String> = DEFAULT_TEXT + options.text

    private val id = options.id
    private val readyDeferred = CompletableDeferred<SindoorNavigator>()
    private var routeLayers = mutableListOf<String>()
    private val stopListening: () -> Unit

    /** Completes once the map has the site (sMap's addIndoor waits for its data); fails when it cannot be drawn. */
    val ready: Deferred<SindoorNavigator> get() = readyDeferred

    /** Where the walker was last shown. */
    var position: SindoorEstimate? = null
        private set

    /** The route shown, if any. */
    var route: SindoorRoute? = null
        private set

    /** The layer ids the navigator draws: the blue dot, its accuracy circle, and route lines `<id>-route-<n>`. */
    val dotLayer: String get() = "$id-me"
    val accuracyLayer: String get() = "$id-me-acc"

    init {
        stopListening = surface.onIndoorLevelChange { which, _ -> if (which == id) redrawDot() }
        surface.addIndoor(id, site.layerJson(), options.level, options.control) { e ->
            if (e == null) readyDeferred.complete(this) else readyDeferred.completeExceptionally(e)
        }
    }

    /** The level shown. */
    val level: String? get() = surface.getIndoorLevel(id)

    fun setLevel(level: String) = surface.setIndoorLevel(id, level)

    /** Shows where the walker is (an estimate of a SindoorLocator), or nothing for null. */
    fun showPosition(e: SindoorEstimate?) {
        position = e
        if (e != null && options.follow && e.level != level) setLevel(e.level)
        redrawDot()
    }

    private fun redrawDot() {
        surface.removeLayer(dotLayer)
        surface.removeLayer(accuracyLayer)
        val e = position ?: return
        val at = site.toLngLat(e.level, e.x, e.y)
        val ref = SindoorIndoorRef(id, e.level)
        if (e.accMm > 0) surface.addCircle(accuracyLayer, at, e.accMm / 1000, options.colors.accuracy, options.colors.accuracyOpacity, ref)
        surface.addPoint(dotLayer, at, options.colors.dot, 7f, "#ffffff", 2f, ref)
    }

    /**
     * Walks to [target] (a ref such as `fixture:12`, millimetres or a longitude / latitude on a level) from the shown
     * position, or from [from]; draws the route and fills the step list. Throws [SindoorException] (`no_position`,
     * the engine's `unknown_point`, `unreachable`, …; then the step list says there is no route).
     */
    fun navigateTo(target: SindoorPoint, from: SindoorPoint? = null): SindoorRoute {
        val start = from ?: position?.let { SindoorPoint.Xy(it.level, it.x, it.y) }
            ?: throw SindoorException("no_position", "no position yet: pass from or call showPosition first")
        val r = try {
            site.route(start, target, role = options.role, profile = options.profile)
        } catch (e: SindoorException) {
            clearRoute()
            panel(listOf(SindoorStepLine("no_route", null, 0.0, text.getValue("no_route"))))
            throw e
        }
        showRoute(r)
        return r
    }

    /** [navigateTo] a ref. */
    fun navigateTo(target: String, from: String? = null): SindoorRoute = navigateTo(SindoorPoint.Ref(target), from?.let { SindoorPoint.Ref(it) })

    /** One line per level walked, as the map draws them. */
    fun routeLines(r: SindoorRoute): List<SindoorRouteLine> = r.legs.mapIndexed { i, leg ->
        SindoorRouteLine("$id-route-$i", leg.level, leg.polyline.map { site.toLngLat(leg.level, it.x, it.y) })
    }

    /** Draws an engine route and its steps. */
    fun showRoute(r: SindoorRoute) {
        clearRoute()
        route = r
        for (line in routeLines(r)) {
            surface.addLine(line.id, line.coordinates, options.colors.route, 5f, SindoorIndoorRef(id, line.level))
            routeLayers.add(line.id)
        }
        panel(steps(r))
    }

    /** The route's steps as text lines (also what the step list shows). */
    fun steps(r: SindoorRoute? = route): List<SindoorStepLine> = (r?.steps ?: emptyList()).map { s ->
        val what = text[s.kind] ?: s.kind
        val dist = if (s.distanceMm > 0) " · " + fmt(text.getValue("metres"), mapOf("n" to (s.distanceMm / 1000).roundToLong().toString())) else ""
        SindoorStepLine(s.kind, s.level.ifEmpty { null }, s.distanceMm, "$what$dist")
    }

    fun clearRoute() {
        for (l in routeLayers) surface.removeLayer(l)
        routeLayers = mutableListOf()
        route = null
        panel(emptyList())
    }

    private fun panel(lines: List<SindoorStepLine>) {
        options.stepsView?.setSteps(lines, text["level"] ?: "Level")
        options.onSteps?.invoke(lines)
    }

    /** Removes everything the navigator drew, the indoor layer with it, and stops listening to the map. */
    fun destroy() {
        clearRoute()
        position = null
        redrawDot()
        stopListening()
        surface.removeIndoor(id)
    }
}
