package ca.superroute.sindoor.map

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.util.TypedValue
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * The navigator's step list: one line per step, numbered, with the level where it changes. Pass it as
 * [SindoorNavigatorOptions.stepsView]; style it through [textColor], [textSizeSp] or by subclassing [makeLine].
 */
open class SindoorStepsView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : ScrollView(context, attrs) {
    private val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }

    var textColor: Int = 0xFF1F2937.toInt()
    var textSizeSp: Float = 15f

    /** The lines shown. */
    var lines: List<SindoorStepLine> = emptyList()
        private set

    init {
        addView(list, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    /** Shows [steps]; [levelWord] heads a line where the level changes. */
    fun setSteps(steps: List<SindoorStepLine>, levelWord: String = "Level") {
        lines = steps
        list.removeAllViews()
        val manyLevels = steps.mapNotNull { it.level }.distinct().size > 1
        var lastLevel: String? = null
        steps.forEachIndexed { i, s ->
            if (manyLevels && s.level != null && s.level != lastLevel) {
                list.addView(makeLine("$levelWord ${s.level}", header = true))
            }
            lastLevel = s.level ?: lastLevel
            list.addView(makeLine(if (s.kind == "no_route") s.text else "${i + 1}. ${s.text}", header = false))
        }
        scrollTo(0, 0)
    }

    protected open fun makeLine(text: String, header: Boolean): TextView = TextView(context).apply {
        this.text = text
        setTextColor(textColor)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, if (header) textSizeSp - 2 else textSizeSp)
        if (header) setTypeface(typeface, Typeface.BOLD)
        val pad = (6 * resources.displayMetrics.density).toInt()
        setPadding(pad * 2, pad, pad * 2, pad)
    }
}
