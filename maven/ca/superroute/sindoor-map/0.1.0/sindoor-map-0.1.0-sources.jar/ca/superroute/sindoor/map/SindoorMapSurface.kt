package ca.superroute.sindoor.map

import ca.superroute.sindoor.SindoorLngLat

/** A layer's tie to one level of the indoor layer: shown only while the indoor layer [id] shows [level]. */
data class SindoorIndoorRef(val id: String, val level: String)

/**
 * The part of an sMap map the navigator draws on (sMap's indoor layer and three layer kinds). [SMapSurface] is it on
 * sMap Android's `SMap`; another map (a test, a wrapper) may give its own.
 */
interface SindoorMapSurface {
    /** Draws the indoor layer from its GeoJSON text; [done] gets null once the data is in, else what failed. */
    fun addIndoor(id: String, geojson: String, level: String?, control: Boolean, done: (Throwable?) -> Unit)
    fun getIndoorLevel(id: String): String?
    fun setIndoorLevel(id: String, level: String)
    fun removeIndoor(id: String)

    /** A point of [radiusPx] in [color] with a white outline. */
    fun addPoint(id: String, at: SindoorLngLat, color: String, radiusPx: Float, strokeColor: String, strokeWidthPx: Float, indoor: SindoorIndoorRef)

    /** A circle of [radiusM] metres filled with [color] at [opacity]. */
    fun addCircle(id: String, at: SindoorLngLat, radiusM: Double, color: String, opacity: Float, indoor: SindoorIndoorRef)

    fun addLine(id: String, coordinates: List<SindoorLngLat>, color: String, widthPx: Float, indoor: SindoorIndoorRef)

    /** Removes a layer of [addPoint] / [addCircle] / [addLine]; nothing for an unknown id. */
    fun removeLayer(id: String)

    /** Listens for the indoor layer's level changes (`indoorlevelchange`); the answer stops listening. */
    fun onIndoorLevelChange(listener: (id: String, level: String) -> Unit): () -> Unit
}
