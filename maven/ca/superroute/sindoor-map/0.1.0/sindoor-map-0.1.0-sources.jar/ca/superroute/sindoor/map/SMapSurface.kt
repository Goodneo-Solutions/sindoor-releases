package ca.superroute.sindoor.map

import ca.superroute.sindoor.SindoorLngLat
import ca.superroute.smap.SMap
import ca.superroute.smap.SMapCircleOptions
import ca.superroute.smap.SMapEvent
import ca.superroute.smap.SMapEventType
import ca.superroute.smap.SMapFeatureValue
import ca.superroute.smap.SMapIndoorOptions
import ca.superroute.smap.SMapIndoorRef
import ca.superroute.smap.SMapIndoorSource
import ca.superroute.smap.SMapLine
import ca.superroute.smap.SMapLineOptions
import ca.superroute.smap.SMapPoint
import ca.superroute.smap.SMapPointOptions
import ca.superroute.smap.SMapPolygonOptions
import org.maplibre.android.geometry.LatLng

/** [SindoorMapSurface] on sMap Android's map view (its indoor layer, `addPoints`, `addCircles`, `addLines`). */
class SMapSurface(val map: SMap) : SindoorMapSurface {
    private fun ref(r: SindoorIndoorRef) = SMapIndoorRef(r.id, r.level)

    override fun addIndoor(id: String, geojson: String, level: String?, control: Boolean, done: (Throwable?) -> Unit) =
        map.addIndoor(id, SMapIndoorSource.GeoJson(geojson), SMapIndoorOptions(level = level, control = control), done)

    override fun getIndoorLevel(id: String): String? = try { map.getIndoorLevel(id) } catch (_: IllegalArgumentException) { null }

    override fun setIndoorLevel(id: String, level: String) = map.setIndoorLevel(id, level)

    override fun removeIndoor(id: String) = map.removeIndoor(id)

    override fun addPoint(id: String, at: SindoorLngLat, color: String, radiusPx: Float, strokeColor: String, strokeWidthPx: Float, indoor: SindoorIndoorRef) {
        map.addPoints(
            id,
            listOf(SMapPoint(at.lat, at.lng)),
            SMapPointOptions(color = color, radius = radiusPx, strokeColor = strokeColor, strokeWidth = SMapFeatureValue.of(strokeWidthPx), overlap = null, indoor = ref(indoor)),
        )
    }

    override fun addCircle(id: String, at: SindoorLngLat, radiusM: Double, color: String, opacity: Float, indoor: SindoorIndoorRef) {
        map.addCircles(
            id,
            listOf(SMapPoint(at.lat, at.lng, mapOf("radius" to radiusM))),
            SMapCircleOptions(area = SMapPolygonOptions(fill = color, opacity = opacity, outline = color, outlineWidth = 0f), indoor = ref(indoor)),
        )
    }

    override fun addLine(id: String, coordinates: List<SindoorLngLat>, color: String, widthPx: Float, indoor: SindoorIndoorRef) {
        map.addLines(id, listOf(SMapLine(coordinates.map { LatLng(it.lat, it.lng) })), SMapLineOptions(color = color, width = widthPx, indoor = ref(indoor)))
    }

    override fun removeLayer(id: String) = map.removeLayer(id)

    override fun onIndoorLevelChange(listener: (id: String, level: String) -> Unit): () -> Unit {
        val l: (SMapEvent) -> Unit = { e -> val id = e.indoorId; val level = e.level; if (id != null && level != null) listener(id, level) }
        map.on(SMapEventType.INDOOR_LEVEL_CHANGE, l)
        return { map.off(SMapEventType.INDOOR_LEVEL_CHANGE, l) }
    }
}
