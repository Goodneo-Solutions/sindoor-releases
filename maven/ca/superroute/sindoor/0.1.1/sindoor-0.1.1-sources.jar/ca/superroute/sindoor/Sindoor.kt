package ca.superroute.sindoor

import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** The sIndoor engine on the device (sIndoor docs/DESIGN.md Part 2h, IK4): its version and where it is loaded from. */
object Sindoor {
    /** The SDK's own version. */
    const val SDK_VERSION: String = BuildConfig.SINDOOR_SDK_VERSION

    /** A full path to the engine library to load instead of the app's `libsindoor_ffi.so` (desktop JVMs, tests). */
    @Volatile
    var libraryPath: String? = null

    /** The engine library's version (loads the library). */
    fun version(): String {
        SindoorNative.load()
        return SindoorNative.version()
    }

    /** Parses an engine or platform answer; `{error}` becomes a [SindoorException]. JSON `null` is Kotlin null. */
    internal fun parse(json: String): Any? {
        val v = JSONTokener(json).nextValue()
        if (v is JSONObject) {
            val e = v.optJSONObject("error")
            if (e != null) throw SindoorException.from(e)
        }
        return if (v == JSONObject.NULL) null else v
    }

    internal fun parseObject(json: String): JSONObject =
        parse(json) as? JSONObject ?: throw SindoorException("bad_answer", "expected a JSON object")
}

/** An error of the engine or of the Open Platform: [code] as they name it, [refs] the points or ids concerned. */
class SindoorException(val code: String, message: String, val refs: List<String> = emptyList()) : Exception(message.ifEmpty { code }) {
    override fun toString(): String = "SindoorException($code): $message"

    internal companion object {
        fun from(e: JSONObject): SindoorException {
            val refs = e.optJSONArray("refs")?.let { a -> (0 until a.length()).map { a.opt(it).toString() } } ?: emptyList()
            return SindoorException(e.optString("code").ifEmpty { "error" }, e.optString("message"), refs)
        }
    }
}

internal fun JSONArray.objects(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
