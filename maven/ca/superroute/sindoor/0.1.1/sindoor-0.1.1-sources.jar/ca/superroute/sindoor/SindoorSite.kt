package ca.superroute.sindoor

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.TimeZone
import kotlin.math.roundToLong

/**
 * A site on the device: downloaded once (or from a cache), compiled by the engine, routed and positioned offline.
 * Close it with [close] (any call after it throws). Calls are thread-safe.
 */
class SindoorSite private constructor(private var handle: Long, download: JSONObject) : AutoCloseable {
    /** What was downloaded (`{site, package, overlay, live}`), for a cache: `SindoorSite.fromDownload(site.download)`. */
    val download: JSONObject = download

    @Volatile private var layerText: String? = null
    @Volatile private var layerCache: JSONObject? = null
    private val anchors = HashMap<String, SindoorAnchor>()

    companion object {
        /** Downloads a site's package through a [SindoorClient] and compiles it here (off the main thread). */
        suspend fun load(site: String, client: SindoorClient, form: String = "customer"): SindoorSite {
            val d = client.`package`(site, form)
            return withContext(Dispatchers.Default) { fromDownload(d) }
        }

        /** A site from a download kept earlier (offline): `{site?, package, overlay: {revision, overlay}, live}`. */
        fun fromDownload(download: JSONObject): SindoorSite {
            val pkg = download.optJSONObject("package") ?: throw SindoorException("bad_download", "expected {package, overlay, live}")
            val ovWrap = download.optJSONObject("overlay")
            val ov = ovWrap?.optJSONObject("overlay") ?: ovWrap ?: JSONObject()
            val rev = ovWrap?.optLong("revision", 0) ?: 0
            val live = download.optJSONArray("live") ?: JSONArray()
            SindoorNative.load()
            val h = SindoorNative.siteNew(pkg.toString(), ov.toString(), live.toString(), rev, true)
            if (h == 0L) throw SindoorException("invalid_site", SindoorNative.lastError())
            return SindoorSite(h, download)
        }

        /** [fromDownload] from its JSON text. */
        fun fromDownload(json: String): SindoorSite =
            fromDownload(try { JSONObject(json) } catch (e: Exception) { throw SindoorException("bad_download", "not JSON: ${e.message}") })

        /** A site package with no download around it (e.g. a file the developer ships with the app). */
        fun fromPackage(pkg: JSONObject, overlay: JSONObject = JSONObject(), live: JSONArray = JSONArray(), revision: Long = 0): SindoorSite =
            fromDownload(JSONObject().put("package", pkg).put("overlay", JSONObject().put("revision", revision).put("overlay", overlay)).put("live", live))

        /** [fromPackage] from the package's JSON text. */
        fun fromPackage(pkg: String, overlay: JSONObject = JSONObject(), live: JSONArray = JSONArray(), revision: Long = 0): SindoorSite =
            fromPackage(try { JSONObject(pkg) } catch (e: Exception) { throw SindoorException("invalid_site", "not JSON: ${e.message}") }, overlay, live, revision)
    }

    private fun h(): Long = handle.also { if (it == 0L) throw IllegalStateException("SindoorSite used after close()") }

    private fun call(what: String, request: String = ""): String = synchronized(this) { SindoorNative.siteCall(h(), what, request) }

    /** The site's id: the download's `site`, else the package's. */
    val id: String?
        get() = download.optString("site").ifEmpty { null } ?: download.optJSONObject("package")?.optJSONObject("site")?.optString("id")?.ifEmpty { null }

    /** The compiled site's version (changes with the package, the overlay and the items in force). */
    val version: String
        get() = Sindoor.parseObject(call("levels")).optString("version")

    /**
     * The walk [from] → [to]: each end a ref, millimetres on a level or a longitude / latitude on a level. [role]
     * (`customer`, `staff`, `delivery`, `all`) uses only that role's entrances, open at [at] (Unix seconds, default
     * now); [profile] a movement profile (default the site's pedestrian). Throws [SindoorException] (`unknown_point`,
     * `unreachable`, `profile`, `role`, …).
     */
    fun route(from: SindoorPoint, to: SindoorPoint, role: String? = null, profile: String? = null, at: Long? = null): SindoorRoute {
        val req = JSONObject().put("from", toEngine(from)).put("to", toEngine(to))
        if (role != null) req.put("role", role)
        if (profile != null) req.put("profile", profile)
        if (at != null) req.put("at", at)
        // Opening hours in the site's zone: the library has no time zone database, the phone on site passes its own.
        req.put("utc_offset_min", TimeZone.getDefault().getOffset(System.currentTimeMillis()) / 60000)
        return SindoorRoute(Sindoor.parseObject(call("route", req.toString())))
    }

    /** [route] between two refs. */
    fun route(from: String, to: String, role: String? = null, profile: String? = null): SindoorRoute =
        route(SindoorPoint.Ref(from), SindoorPoint.Ref(to), role, profile)

    /** A list of targets in the shortest order (IV13): `{targets, start?, end?, …}` as the engine takes it. */
    fun tour(request: JSONObject): JSONObject = Sindoor.parseObject(call("tour", request.toString()))

    /** From a parking point / delivery point (IV5): `{kind?, role?, profile?, vehicle_class?, portal?}`. */
    fun approach(request: JSONObject = JSONObject()): JSONObject = Sindoor.parseObject(call("approach", request.toString()))

    /** The levels to draw (outline, obstacles, access points), as the engine lists them. */
    fun levels(): JSONArray = Sindoor.parseObject(call("levels")).optJSONArray("levels") ?: JSONArray()

    /** The indoor layer's GeoJSON — what sMap's `addIndoor` draws — as text. */
    fun layerJson(): String = layerText ?: call("layer").also { Sindoor.parseObject(it); layerText = it }

    /** The indoor layer's GeoJSON (`{type: FeatureCollection, frame, site, version, levels, features}`). */
    fun layer(): JSONObject = layerCache ?: Sindoor.parseObject(layerJson()).also { layerCache = it }

    /** A level's geo anchor as the layer lists it. */
    fun anchor(level: String): SindoorAnchor = synchronized(anchors) {
        anchors.getOrPut(level) {
            val l = (layer().optJSONArray("levels") ?: JSONArray()).objects().firstOrNull { it.optString("id") == level }
                ?: throw SindoorException("unknown_level", "no level $level", listOf(level))
            SindoorAnchor.fromJson(l.optJSONObject("anchor"))
        }
    }

    /** Level millimetres → longitude / latitude. */
    fun toLngLat(level: String, x: Double, y: Double): SindoorLngLat = SindoorGeo.levelToLngLat(anchor(level), x, y)

    /** Longitude / latitude on a level → millimetres (rounded). */
    fun fromLngLat(level: String, lng: Double, lat: Double): SindoorPoint.Xy {
        val (x, y) = SindoorGeo.lngLatToLevel(anchor(level), lng, lat)
        return SindoorPoint.Xy(level, x.roundToLong().toDouble(), y.roundToLong().toDouble())
    }

    /** A route end as the engine takes it. */
    fun toEngine(p: SindoorPoint): Any = when (p) {
        is SindoorPoint.Ref -> p.ref
        is SindoorPoint.LngLat -> toEngine(fromLngLat(p.level, p.lng, p.lat))
        is SindoorPoint.Xy -> JSONObject().put("x", p.x.roundToLong()).put("y", p.y.roundToLong()).also { if (p.level != null) it.put("level", p.level) }
    }

    /** A positioning filter running here (steps, heading, pressure, beacons, scans, GPS → estimates). */
    fun locator(config: JSONObject = JSONObject()): SindoorLocator = SindoorLocator(this, config)

    internal fun handleForLocator(): Long = h()

    override fun close() {
        synchronized(this) {
            val x = handle
            handle = 0
            if (x != 0L) SindoorNative.siteFree(x)
        }
    }
}
