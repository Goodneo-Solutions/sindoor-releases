package ca.superroute.sindoor

/** A route end: an access point by ref (`door`, `fixture:12`), a point on a level in millimetres, or a longitude /
 *  latitude on a level (turned into millimetres through the level's anchor). */
sealed class SindoorPoint {
    data class Ref(val ref: String) : SindoorPoint()

    data class Xy(val level: String?, val x: Double, val y: Double) : SindoorPoint()

    data class LngLat(val level: String, val lng: Double, val lat: Double) : SindoorPoint()

    companion object {
        fun ref(ref: String): SindoorPoint = Ref(ref)
        fun xy(level: String?, x: Double, y: Double): SindoorPoint = Xy(level, x, y)
        fun lngLat(level: String, lng: Double, lat: Double): SindoorPoint = LngLat(level, lng, lat)
    }
}

/** A floor position in millimetres. */
data class SindoorXy(val x: Double, val y: Double)
