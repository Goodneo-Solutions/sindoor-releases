package ca.superroute.sindoor

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** An HTTP answer: [status] and the body's text. */
data class SindoorHttpResponse(val status: Int, val body: String)

/** The HTTP layer of [SindoorClient] (blocking; called off the main thread). Replace it to use the app's own client. */
fun interface SindoorHttp {
    fun request(method: String, url: String, headers: Map<String, String>, body: String?): SindoorHttpResponse
}

/** [SindoorHttp] over HttpURLConnection. */
object SindoorUrlConnectionHttp : SindoorHttp {
    override fun request(method: String, url: String, headers: Map<String, String>, body: String?): SindoorHttpResponse {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            for ((k, v) in headers) c.setRequestProperty(k, v)
            if (body != null) {
                c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val status = c.responseCode
            val stream = if (status >= 400) c.errorStream else c.inputStream
            val text = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            return SindoorHttpResponse(status, text)
        } finally {
            c.disconnect()
        }
    }
}

/**
 * The Open Platform's indoor routes (sIndoor docs/DESIGN.md Part 2h, "P6 interfaces"): a site's package for the
 * device, its layer, public sites, and a token for the full form.
 *
 * @param key an sMap map key (`smk_…`): the customer form of the account's own and public sites
 * @param token an sIndoor token (`si1.…`) the developer's server got from `POST /v1/indoor/token`: the full form
 * @param apiKey an Open Platform server key — only on a server, never in an app
 */
class SindoorClient(
    val key: String? = null,
    val token: String? = null,
    val apiKey: String? = null,
    baseUrl: String = DEFAULT_BASE_URL,
    private val http: SindoorHttp = SindoorUrlConnectionHttp,
) {
    val baseUrl: String = baseUrl.trimEnd('/')

    companion object {
        const val DEFAULT_BASE_URL = "https://open.superroute.ca/v1/indoor"

        private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

        /** A number as JavaScript writes it (`43` rather than `43.0`). */
        internal fun num(d: Double): String = if (d == Math.rint(d) && !d.isInfinite() && Math.abs(d) < 1e15) d.toLong().toString() else d.toString()
    }

    fun headers(): Map<String, String> {
        val h = linkedMapOf("Accept" to "application/json")
        (token ?: apiKey)?.let { h["Authorization"] = "Bearer $it" }
        key?.let { h["X-SMap-Key"] = it }
        return h
    }

    fun url(path: String, query: Map<String, String?> = emptyMap()): String {
        val q = LinkedHashMap<String, String>()
        if (key != null && token == null) q["key"] = key
        for ((k, v) in query) if (v != null) q[k] = v
        val qs = q.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value)}" }
        return baseUrl + path + if (qs.isEmpty()) "" else "?$qs"
    }

    /** One call: the answer's JSON (an object, an array or null); an error answer throws [SindoorException]. */
    suspend fun request(method: String, path: String, query: Map<String, String?> = emptyMap(), body: JSONObject? = null): Any? =
        withContext(Dispatchers.IO) {
            val headers = headers().toMutableMap()
            if (body != null) headers["Content-Type"] = "application/json"
            val r = try {
                http.request(method, url(path, query), headers, body?.toString())
            } catch (e: IOException) {
                throw SindoorException("network", e.message ?: "network error")
            }
            val v: Any? = try { if (r.body.isBlank()) null else org.json.JSONTokener(r.body).nextValue().takeIf { it != JSONObject.NULL } } catch (_: Exception) { null }
            if (r.status !in 200..399) {
                val e = (v as? JSONObject)?.optJSONObject("error")
                if (e != null && e.optString("code").isNotEmpty()) throw SindoorException.from(e)
                throw SindoorException("http_${r.status}", e?.optString("message")?.ifEmpty { null } ?: "HTTP ${r.status}")
            }
            v
        }

    private suspend fun obj(method: String, path: String, query: Map<String, String?> = emptyMap(), body: JSONObject? = null): JSONObject =
        request(method, path, query, body) as? JSONObject ?: throw SindoorException("bad_answer", "expected a JSON object")

    /** `{site, package, overlay: {revision, overlay}, live}` — the form the credentials allow (customer by default). */
    suspend fun `package`(site: String, form: String = "customer"): JSONObject = obj("GET", "/sites/${enc(site)}/package", mapOf("form" to form))

    /** The site's indoor layer GeoJSON. */
    suspend fun layer(site: String): JSONObject = obj("GET", "/sites/${enc(site)}/layer")

    /** Public sites in a bounding box `[west, south, east, north]`: `[{site, name, bbox, levels}]`. */
    suspend fun publicSites(bbox: List<Double>): JSONArray =
        request("GET", "/public-sites", mapOf("bbox" to bbox.joinToString(",") { num(it) })) as? JSONArray ?: JSONArray()

    /** Server side only (an Open Platform key): a short-lived token for the full form of a site → `{token, expires_at}`. */
    suspend fun issueToken(site: String, form: String = "full", subject: String? = null, ttlS: Int? = null): JSONObject {
        val b = JSONObject().put("site", site).put("form", form)
        if (subject != null) b.put("subject", subject)
        if (ttlS != null) b.put("ttl_s", ttlS)
        return obj("POST", "/token", body = b)
    }
}
