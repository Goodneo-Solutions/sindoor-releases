package ca.superroute.sindoor

/**
 * The engine's JNI entry points (crates/sindoor-ffi/src/android.rs, cargo feature `jni`). Answers are JSON; an
 * `{"error": {code, message, refs}}` answer is an error. Handles are the library's pointers (0 = none).
 */
internal object SindoorNative {
    @Volatile private var loaded = false

    /** Opens the library once: a path from the system property `sindoor.library` (JVM tests), else the app's own. */
    @Synchronized
    fun load() {
        if (loaded) return
        val path = Sindoor.libraryPath ?: System.getProperty("sindoor.library")?.takeIf { it.isNotEmpty() }
        try {
            if (path != null) System.load(path) else System.loadLibrary("sindoor_ffi")
        } catch (e: UnsatisfiedLinkError) {
            throw SindoorException("unavailable", "the sIndoor engine library cannot be loaded: ${e.message}")
        }
        loaded = true
    }

    @JvmStatic external fun version(): String
    @JvmStatic external fun siteNew(src: String, overlay: String, live: String, revision: Long, `package`: Boolean): Long
    @JvmStatic external fun lastError(): String
    @JvmStatic external fun siteFree(site: Long)
    @JvmStatic external fun siteCall(site: Long, what: String, request: String): String
    @JvmStatic external fun locatorNew(site: Long, config: String): Long
    @JvmStatic external fun locatorCall(loc: Long, what: String, request: String): String
    @JvmStatic external fun locatorFree(loc: Long)
}
