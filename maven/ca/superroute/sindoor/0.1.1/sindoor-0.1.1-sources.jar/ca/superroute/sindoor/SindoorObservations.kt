package ca.superroute.sindoor

import org.json.JSONArray
import org.json.JSONObject

/** The observations the phone feeds a [SindoorLocator], in the engine's wire format ([t] milliseconds since 1970). */
object SindoorObservations {
    /** [n] steps walked towards [headingDeg], counted from north clockwise (`frame: north`). */
    fun steps(t: Long, n: Int, headingDeg: Double): JSONObject =
        JSONObject().put("t", t).put("kind", "steps").put("n", n).put("heading_deg", round1(normalizeDeg(headingDeg))).put("frame", "north")

    /** The phone's heading from the fused rotation sensor, counted from north clockwise. */
    fun heading(t: Long, deg: Double): JSONObject =
        JSONObject().put("t", t).put("kind", "heading").put("deg", round1(normalizeDeg(deg))).put("source", "fused").put("frame", "north")

    /** The barometer's reading in hectopascals. */
    fun pressure(t: Long, hpa: Double): JSONObject =
        JSONObject().put("t", t).put("kind", "pressure").put("hpa", Math.round(hpa * 100) / 100.0)

    /** The beacons heard in a window: `(id, rssi)`, ids as [SindoorBeaconFrames] makes them. */
    fun ble(t: Long, beacons: List<Pair<String, Int>>): JSONObject {
        val a = JSONArray()
        for ((id, rssi) in beacons) a.put(JSONObject().put("id", id).put("rssi", rssi))
        return JSONObject().put("t", t).put("kind", "ble").put("beacons", a)
    }

    /** A scanned code or a tapped access point: a fix at that ref. */
    fun scan(t: Long, ref: String): JSONObject = JSONObject().put("t", t).put("kind", "scan").put("ref", ref)

    /** Degrees into 0 ≤ d < 360. */
    fun normalizeDeg(d: Double): Double {
        val r = d % 360.0
        return if (r < 0) r + 360.0 else r
    }

    private fun round1(d: Double): Double = Math.round(d * 10) / 10.0
}
