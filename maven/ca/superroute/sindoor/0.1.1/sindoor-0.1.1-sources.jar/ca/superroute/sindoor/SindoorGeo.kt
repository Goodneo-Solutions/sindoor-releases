package ca.superroute.sindoor

import org.json.JSONObject
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** A level's place on the earth (its geo anchor): x east and y south of it at rotation 0, in millimetres. */
data class SindoorAnchor(val lat: Double, val lon: Double, val rotationDeg: Double = 0.0, val scale: Double = 1.0) {
    companion object {
        /** The anchor of a level without one (`frame: local`): laid at 0° / 0°. */
        val LOCAL = SindoorAnchor(0.0, 0.0)

        fun fromJson(j: JSONObject?): SindoorAnchor = if (j == null) LOCAL else SindoorAnchor(
            j.optDouble("lat", 0.0),
            j.optDouble("lon", 0.0),
            j.optDouble("rotation_deg", 0.0).let { if (it.isNaN()) 0.0 else it },
            j.optDouble("scale", 1.0).let { if (it.isNaN()) 1.0 else it },
        )
    }
}

/** A longitude / latitude pair. */
data class SindoorLngLat(val lng: Double, val lat: Double)

/**
 * Level millimetres ↔ longitude / latitude through a level's anchor: the formulas of sIndoor's
 * `sindoor_model::outdoor` (`level_to_geo` / `geo_to_level`), so the SDK, sMap's indoor layer and the engine agree.
 */
object SindoorGeo {
    /** Millimetres per degree of latitude and of longitude at [lat]. */
    fun mmPerDegree(lat: Double): DoubleArray {
        val r = lat * PI / 180
        val latM = 111132.92 - 559.82 * cos(2 * r) + 1.175 * cos(4 * r)
        val lonM = 111412.84 * cos(r) - 93.5 * cos(3 * r)
        return doubleArrayOf(latM * 1000, lonM * 1000)
    }

    /** A level point (mm, x east, y south) → longitude / latitude. */
    fun levelToLngLat(anchor: SindoorAnchor, x: Double, y: Double): SindoorLngLat {
        val (kLat, kLon) = mmPerDegree(anchor.lat).let { it[0] to it[1] }
        val rot = anchor.rotationDeg * PI / 180
        val s = sin(rot)
        val c = cos(rot)
        val xs = x * anchor.scale
        val ys = y * anchor.scale
        val e = xs * c - ys * s
        val south = xs * s + ys * c
        return SindoorLngLat(anchor.lon + e / kLon, anchor.lat - south / kLat)
    }

    /** Longitude / latitude → a level point (mm) as (x, y). */
    fun lngLatToLevel(anchor: SindoorAnchor, lng: Double, lat: Double): Pair<Double, Double> {
        val (kLat, kLon) = mmPerDegree(anchor.lat).let { it[0] to it[1] }
        val e = (lng - anchor.lon) * kLon
        val south = -(lat - anchor.lat) * kLat
        val rot = anchor.rotationDeg * PI / 180
        val s = sin(rot)
        val c = cos(rot)
        val k = anchor.scale
        return (e * c + south * s) / k to (-e * s + south * c) / k
    }
}
