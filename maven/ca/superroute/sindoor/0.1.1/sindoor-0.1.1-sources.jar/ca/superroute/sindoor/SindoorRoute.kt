package ca.superroute.sindoor

import org.json.JSONArray
import org.json.JSONObject

private fun xy(v: Any?): SindoorXy {
    val a = v as? JSONArray ?: return SindoorXy(0.0, 0.0)
    return SindoorXy(a.optDouble(0, 0.0), a.optDouble(1, 0.0))
}

/** One instruction: what to do ([kind]: start, straight, slight_left, left, sharp_left, slight_right, right,
 *  sharp_right, u_turn, connector, arrive) at [at] on [level], then walk [distanceMm] to the next one. */
data class SindoorStep(
    val kind: String,
    val level: String,
    val distanceMm: Double,
    val at: SindoorXy,
    /** Signed turn, positive = right. */
    val angleDeg: Double?,
    /** On a connector step: its id, kind (`elevator`, `stairs`, `escalator`, `ramp`, …) and the level reached. */
    val connector: String?,
    val connectorKind: String?,
    val toLevel: String?,
) {
    internal companion object {
        fun from(j: JSONObject) = SindoorStep(
            kind = j.optString("kind"),
            level = j.optString("level"),
            distanceMm = j.optDouble("distance_mm", 0.0),
            at = xy(j.opt("at")),
            angleDeg = if (j.has("angle_deg") && !j.isNull("angle_deg")) j.optDouble("angle_deg") else null,
            connector = j.optString("connector").takeIf { j.has("connector") && !j.isNull("connector") },
            connectorKind = j.optString("connector_kind").takeIf { j.has("connector_kind") && !j.isNull("connector_kind") },
            toLevel = j.optString("to_level").takeIf { j.has("to_level") && !j.isNull("to_level") },
        )
    }
}

/** The part of a route on one level: its polyline in the level's millimetres. */
data class SindoorLeg(val level: String, val polyline: List<SindoorXy>)

/** The engine's route (`{length_mm, duration_s, legs, steps, connectors, version}`); [json] is the answer as it came. */
class SindoorRoute(val json: JSONObject) {
    val lengthMm: Double = json.optDouble("length_mm", 0.0)
    val durationS: Double = json.optDouble("duration_s", 0.0)
    val version: String = json.optString("version")
    val legs: List<SindoorLeg> = (json.optJSONArray("legs") ?: JSONArray()).objects().map { l ->
        val p = l.optJSONArray("polyline") ?: JSONArray()
        SindoorLeg(l.optString("level"), (0 until p.length()).map { xy(p.opt(it)) })
    }
    val connectors: List<String> = (json.optJSONArray("connectors") ?: JSONArray()).let { a -> (0 until a.length()).map { a.optString(it) } }
    val steps: List<SindoorStep> = (json.optJSONArray("steps") ?: JSONArray()).objects().map(SindoorStep::from)

    override fun toString(): String = "SindoorRoute(${lengthMm.toLong()} mm, ${legs.size} legs, ${steps.size} steps)"
}
