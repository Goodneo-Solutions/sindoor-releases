package ca.superroute.sindoor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import org.json.JSONObject
import kotlin.math.abs

/**
 * The phone's motion sensors fed to a locator: steps (step detector, else step counter), the heading from the rotation
 * vector (counted from north, `frame: north`) and the barometer, as [SindoorObservations]. [start] / [stop] may be
 * called any number of times; [bind] follows a lifecycle (on while resumed). Observations are delivered on the main
 * thread to [onObservation]; [SindoorSensors.forLocator] feeds a locator and reports each estimate.
 *
 * The rotation vector counts from magnetic north: pass the place's [declinationDeg] (Android's GeomagneticField) for
 * true north.
 */
class SindoorSensors(
    context: Context,
    private val onObservation: (JSONObject) -> Unit,
) {
    private val sensors = context.applicationContext.getSystemService(Context.SENSOR_SERVICE) as SensorManager?
    private val main = Handler(Looper.getMainLooper())
    private var running = false
    private var lastCounter = -1f
    private var lastHeadingT = 0L
    private var lastHeadingSent = Double.NaN
    private var lastPressureT = 0L
    private var lifecycle: Lifecycle? = null
    private val rot = FloatArray(9)
    private val orient = FloatArray(3)

    /** Added to the sensor's magnetic heading (east positive). */
    @Volatile var declinationDeg: Double = 0.0

    /** The current heading from north (NaN before the first reading). */
    @Volatile var headingDeg: Double = Double.NaN
        private set

    /** The least time between two heading / pressure observations, milliseconds. */
    var headingEveryMs: Long = 500
    var pressureEveryMs: Long = 1000

    companion object {
        /** Sensors feeding [locator]; each estimate (non-null) goes to [onEstimate] on the main thread. */
        fun forLocator(context: Context, locator: SindoorLocator, onEstimate: (SindoorEstimate) -> Unit = {}): SindoorSensors =
            SindoorSensors(context) { o -> locator.observe(o)?.let(onEstimate) }

        /** A sensor event's time as milliseconds since 1970. */
        internal fun wallMillis(eventNanos: Long): Long =
            System.currentTimeMillis() + (eventNanos - SystemClock.elapsedRealtimeNanos()) / 1_000_000
    }

    /** Which inputs this phone has. */
    val hasSteps: Boolean get() = sensors?.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR) != null || sensors?.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) != null
    val hasHeading: Boolean get() = sensors?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR) != null
    val hasPressure: Boolean get() = sensors?.getDefaultSensor(Sensor.TYPE_PRESSURE) != null

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val t = wallMillis(e.timestamp)
            when (e.sensor.type) {
                Sensor.TYPE_ROTATION_VECTOR -> {
                    SensorManager.getRotationMatrixFromVector(rot, e.values)
                    SensorManager.getOrientation(rot, orient)
                    val deg = SindoorObservations.normalizeDeg(Math.toDegrees(orient[0].toDouble()) + declinationDeg)
                    headingDeg = deg
                    val turned = lastHeadingSent.isNaN() || abs(((deg - lastHeadingSent + 540) % 360) - 180) >= 2
                    if (turned && t - lastHeadingT >= headingEveryMs) {
                        lastHeadingT = t
                        lastHeadingSent = deg
                        emit(SindoorObservations.heading(t, deg))
                    }
                }
                Sensor.TYPE_STEP_DETECTOR -> if (!headingDeg.isNaN()) emit(SindoorObservations.steps(t, 1, headingDeg))
                Sensor.TYPE_STEP_COUNTER -> {
                    val c = e.values[0]
                    val n = if (lastCounter < 0) 0 else (c - lastCounter).toInt()
                    lastCounter = c
                    if (n in 1..50 && !headingDeg.isNaN()) emit(SindoorObservations.steps(t, n, headingDeg))
                }
                Sensor.TYPE_PRESSURE -> if (t - lastPressureT >= pressureEveryMs) {
                    lastPressureT = t
                    emit(SindoorObservations.pressure(t, e.values[0].toDouble()))
                }
            }
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun emit(o: JSONObject) {
        if (Looper.myLooper() == Looper.getMainLooper()) onObservation(o) else main.post { if (running) onObservation(o) }
    }

    /** Starts listening; true when at least one input is there. */
    @Synchronized
    fun start(): Boolean {
        val sm = sensors ?: return false
        if (running) return true
        var any = false
        sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)?.let { any = sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI) || any }
        val detector = sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR)
        if (detector != null) {
            any = sm.registerListener(listener, detector, SensorManager.SENSOR_DELAY_FASTEST) || any
        } else {
            sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)?.let { lastCounter = -1f; any = sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_FASTEST) || any }
        }
        sm.getDefaultSensor(Sensor.TYPE_PRESSURE)?.let { any = sm.registerListener(listener, it, SensorManager.SENSOR_DELAY_NORMAL) || any }
        running = any
        return any
    }

    @Synchronized
    fun stop() {
        if (!running) return
        running = false
        sensors?.unregisterListener(listener)
        lastHeadingSent = Double.NaN
    }

    val isRunning: Boolean get() = running

    private val observer = object : DefaultLifecycleObserver {
        override fun onResume(owner: LifecycleOwner) { start() }
        override fun onPause(owner: LifecycleOwner) { stop() }
        override fun onDestroy(owner: LifecycleOwner) { unbind() }
    }

    /** On while [owner] is resumed, off when paused, let go when destroyed. Call on the main thread. */
    fun bind(owner: LifecycleOwner) {
        unbind()
        lifecycle = owner.lifecycle.also { it.addObserver(observer) }
    }

    fun unbind() {
        lifecycle?.removeObserver(observer)
        lifecycle = null
        stop()
    }
}
