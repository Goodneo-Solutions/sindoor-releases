package ca.superroute.sindoor

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import org.json.JSONObject

/**
 * Beacon frames and the one-second window (sIndoor docs/DESIGN.md IQ13), with the same ids as Superroute Edge's
 * gateway: `ib:<uuid>:<major>:<minor>` for iBeacon, `ed:<namespace>:<instance>` for Eddystone-UID. Pure Kotlin.
 */
object SindoorBeaconFrames {
    const val APPLE_COMPANY_ID = 0x004C
    const val MAX_PER_MESSAGE = 200

    /** Eddystone's service (0xFEAA). */
    val EDDYSTONE_UUID: java.util.UUID = java.util.UUID.fromString("0000feaa-0000-1000-8000-00805f9b34fb")

    private fun hex(b: ByteArray, from: Int, to: Int): String =
        (from until to).joinToString("") { "%02x".format(b[it].toInt() and 0xff) }

    /** Apple manufacturer data (after the company id): 0x02 0x15, UUID, major, minor, tx → `ib:<uuid>:<major>:<minor>`. */
    fun iBeaconId(d: ByteArray?): String? {
        if (d == null || d.size < 23 || d[0] != 0x02.toByte() || d[1] != 0x15.toByte()) return null
        val u = hex(d, 2, 18)
        val uuid = "${u.substring(0, 8)}-${u.substring(8, 12)}-${u.substring(12, 16)}-${u.substring(16, 20)}-${u.substring(20, 32)}"
        val major = ((d[18].toInt() and 0xff) shl 8) or (d[19].toInt() and 0xff)
        val minor = ((d[20].toInt() and 0xff) shl 8) or (d[21].toInt() and 0xff)
        return "ib:$uuid:$major:$minor"
    }

    /** Eddystone service data: frame 0x00 (UID), tx, 10-byte namespace, 6-byte instance → `ed:<namespace>:<instance>`. */
    fun eddystoneUidId(d: ByteArray?): String? {
        if (d == null || d.size < 18 || d[0] != 0x00.toByte()) return null
        return "ed:${hex(d, 2, 12)}:${hex(d, 12, 18)}"
    }

    /** The strongest RSSI per id until flushed. Thread-safe. */
    class Window {
        private val best = HashMap<String, Int>()

        @Synchronized
        fun add(id: String?, rssi: Int) {
            if (id.isNullOrEmpty() || rssi >= 0 || rssi < -127) return
            val old = best[id]
            if (old == null || rssi > old) best[id] = rssi
        }

        /** Strongest first, at most [MAX_PER_MESSAGE]; empties the window. */
        @Synchronized
        fun flush(): List<Pair<String, Int>> {
            val out = best.entries.map { it.key to it.value }
                .sortedWith(compareByDescending<Pair<String, Int>> { it.second }.thenBy { it.first })
                .take(MAX_PER_MESSAGE)
            best.clear()
            return out
        }
    }
}

/**
 * BLE beacons heard by the phone, fed to a locator as one `ble {beacons: [{id, rssi}]}` observation per second (only
 * when something was heard). The SDK never asks for a permission: [start] answers what is missing ([missingPermissions])
 * and the app asks the user itself. [bind] follows a lifecycle.
 */
class SindoorBeacons(
    context: Context,
    private val onObservation: (JSONObject) -> Unit,
) {
    /** What [start] found. */
    sealed class Status {
        object Started : Status()
        data class MissingPermissions(val permissions: List<String>) : Status()
        object BluetoothOff : Status()
        object NotSupported : Status()
    }

    private val app = context.applicationContext
    private val main = Handler(Looper.getMainLooper())
    private val window = SindoorBeaconFrames.Window()
    private var running = false
    private var lifecycle: Lifecycle? = null

    /** The last status [start] answered (also told to [onStatus]). */
    @Volatile var status: Status? = null
        private set

    /** Told every status [start] finds (e.g. to show why positioning by beacons is off). */
    var onStatus: ((Status) -> Unit)? = null

    companion object {
        /** Beacons feeding [locator]; each estimate (non-null) goes to [onEstimate] on the main thread. */
        fun forLocator(context: Context, locator: SindoorLocator, onEstimate: (SindoorEstimate) -> Unit = {}): SindoorBeacons =
            SindoorBeacons(context) { o -> locator.observe(o)?.let(onEstimate) }

        /** The permissions a scan for beacons needs on this Android version. */
        fun requiredPermissions(sdk: Int = Build.VERSION.SDK_INT): List<String> =
            if (sdk >= 31) listOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.ACCESS_FINE_LOCATION)
            else listOf(Manifest.permission.ACCESS_FINE_LOCATION)

        /** The required permissions not granted (the app asks for them; the SDK never does). */
        fun missingPermissions(context: Context): List<String> =
            requiredPermissions().filter { context.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
    }

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) = take(result)
        override fun onBatchScanResults(results: MutableList<ScanResult>) = results.forEach(::take)
        override fun onScanFailed(errorCode: Int) {}
    }

    private fun take(r: ScanResult) {
        val rec = r.scanRecord ?: return
        window.add(SindoorBeaconFrames.iBeaconId(rec.getManufacturerSpecificData(SindoorBeaconFrames.APPLE_COMPANY_ID)), r.rssi)
        window.add(SindoorBeaconFrames.eddystoneUidId(rec.getServiceData(ParcelUuid(SindoorBeaconFrames.EDDYSTONE_UUID))), r.rssi)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val heard = window.flush()
            if (heard.isNotEmpty()) onObservation(SindoorObservations.ble(System.currentTimeMillis(), heard))
            main.postDelayed(this, 1000)
        }
    }

    private fun report(s: Status): Status {
        status = s
        onStatus?.invoke(s)
        return s
    }

    /** Starts scanning (call on the main thread). Nothing is asked of the user: a missing permission is answered. */
    @SuppressLint("MissingPermission")
    fun start(): Status {
        if (running) return Status.Started
        val missing = missingPermissions(app)
        if (missing.isNotEmpty()) return report(Status.MissingPermissions(missing))
        val adapter = (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?)?.adapter ?: return report(Status.NotSupported)
        if (!adapter.isEnabled) return report(Status.BluetoothOff)
        val scanner = adapter.bluetoothLeScanner ?: return report(Status.BluetoothOff)
        val filters = listOf(
            ScanFilter.Builder().setManufacturerData(SindoorBeaconFrames.APPLE_COMPANY_ID, byteArrayOf(0x02, 0x15), byteArrayOf(-1, -1)).build(),
            ScanFilter.Builder().setServiceData(ParcelUuid(SindoorBeaconFrames.EDDYSTONE_UUID), byteArrayOf(0x00), byteArrayOf(-1)).build(),
        )
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).setReportDelay(0).build()
        try {
            scanner.startScan(filters, settings, callback)
        } catch (e: SecurityException) {
            return report(Status.MissingPermissions(requiredPermissions()))
        }
        running = true
        main.postDelayed(tick, 1000)
        return report(Status.Started)
    }

    @SuppressLint("MissingPermission")
    fun stop() {
        if (!running) return
        running = false
        main.removeCallbacks(tick)
        try {
            (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager?)?.adapter?.bluetoothLeScanner?.stopScan(callback)
        } catch (_: SecurityException) {
        } catch (_: IllegalStateException) {
        }
        window.flush()
    }

    val isRunning: Boolean get() = running

    private val observer = object : DefaultLifecycleObserver {
        override fun onResume(owner: LifecycleOwner) { start() }
        override fun onPause(owner: LifecycleOwner) { stop() }
        override fun onDestroy(owner: LifecycleOwner) { unbind() }
    }

    /** On while [owner] is resumed, off when paused, let go when destroyed. Call on the main thread. */
    fun bind(owner: LifecycleOwner) {
        unbind()
        lifecycle = owner.lifecycle.also { it.addObserver(observer) }
    }

    fun unbind() {
        lifecycle?.removeObserver(observer)
        lifecycle = null
        stop()
    }
}
