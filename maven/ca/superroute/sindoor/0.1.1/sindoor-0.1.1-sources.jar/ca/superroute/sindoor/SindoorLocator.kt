package ca.superroute.sindoor

import org.json.JSONArray
import org.json.JSONObject

/** Where the walker is: millimetres on [level], [accMm] a 2 σ radius, [at] the time of the last observation (ms), and
 *  the same point as [lng] / [lat]. [json] is the engine's answer with `lng` / `lat` added. */
data class SindoorEstimate(
    val x: Double,
    val y: Double,
    val level: String,
    val accMm: Double,
    val at: Long,
    val lng: Double,
    val lat: Double,
    val json: JSONObject,
)

/**
 * Indoor positioning on the device: a particle filter on a site, fed observations in the wire format —
 * `{"t": ms, "kind": "scan", "ref": "door"}`, `steps {n, heading_deg, frame?}`, `heading {deg, source?, frame?}`,
 * `pressure {hpa}`, `ble {beacons: [{id, rssi}]}`, … ([SindoorObservations] builds them; [SindoorSensors] and
 * [SindoorBeacons] feed them from the phone). Thread-safe. The site must stay open while the locator is used.
 */
class SindoorLocator internal constructor(val site: SindoorSite, config: JSONObject) : AutoCloseable {
    private var handle: Long

    /** The last estimate, null before the first fix. */
    @Volatile var last: SindoorEstimate? = null
        private set

    init {
        SindoorNative.load()
        handle = SindoorNative.locatorNew(site.handleForLocator(), config.toString())
        if (handle == 0L) throw SindoorException("invalid_config", SindoorNative.lastError())
    }

    private fun call(what: String, request: String = ""): String = synchronized(this) {
        if (handle == 0L) throw IllegalStateException("SindoorLocator used after close()")
        SindoorNative.locatorCall(handle, what, request)
    }

    /** One observation → the estimate after it, null before the first fix. */
    fun observe(observation: JSONObject): SindoorEstimate? = observeJson(observation.toString())

    /** Several observations → the estimate after them. */
    fun observe(observations: JSONArray): SindoorEstimate? = observeJson(observations.toString())

    /** One observation or a list as JSON text. */
    fun observeJson(json: String): SindoorEstimate? {
        val e = Sindoor.parse(call("observe", json)) as? JSONObject ?: return null
        if (!e.has("level")) return null
        val level = e.optString("level")
        val x = e.optDouble("x", 0.0)
        val y = e.optDouble("y", 0.0)
        val p = site.toLngLat(level, x, y)
        e.put("lng", p.lng).put("lat", p.lat)
        return SindoorEstimate(x, y, level, e.optDouble("acc_mm", 0.0), e.optLong("at", 0), p.lng, p.lat, e).also { last = it }
    }

    /** `{step_scale, features}` — keep `step_scale` per person on the device and pass it back in the config. */
    fun state(): JSONObject = Sindoor.parseObject(call("state"))

    /** A new calibration (the site's `GET /calibration` body), or null to drop it. */
    fun setCalibration(calibration: JSONObject?): JSONObject =
        Sindoor.parseObject(call("set_calibration", calibration?.toString() ?: "null"))

    override fun close() {
        synchronized(this) {
            val x = handle
            handle = 0
            if (x != 0L) SindoorNative.locatorFree(x)
        }
    }
}
